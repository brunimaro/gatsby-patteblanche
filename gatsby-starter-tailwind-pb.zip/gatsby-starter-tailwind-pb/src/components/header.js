import { graphql, useStaticQuery, Link } from "gatsby";
import React, { useState } from "react";

// React Component
import Burger from '@animated-burgers/burger-slip'
// don't forget the styles
import '@animated-burgers/burger-slip/dist/styles.css'
import AniLink from "gatsby-plugin-transition-link/AniLink"


function Header() {
  const [isExpanded, toggleExpansion] = useState(false);
  const [isOpen, toggleBurger] = useState(true);
  const { site } = useStaticQuery(graphql`
    query SiteTitleQuery {
      site {
        siteMetadata {
          title
        }
      }
    }
  `);

  return (
    <header className="dark">
      <div className="flex flex-wrap items-center justify-between max-w-4xl p-4 mx-auto md:p-8">
        <Link to="/">
          <h1 className="flex items-center nom-site no-underline">
            <span className="text-xl
             font-bold">
              {site.siteMetadata.title}
            </span>
          </h1>
        </Link>

        <button
          className="flex items-center block px-3 py-2 text-white border border-white rounded md:hidden"
          onClick={() => toggleExpansion(!isExpanded)}
        >
          <svg
            className="w-3 h-3 fill-current"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
          >
            <title>Menu</title>
            <path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z" />
          </svg>
        </button>
        <nav
          className={`${
            isOpen ? `cache` : `actif`
          }`}
        >
          {[
            {
              route: `/`,
              title: `Accueil`,
            },
            {
              route: `/about`,
              title: `About`,
            },
            {
              route: `/contact`,
              title: `Contact`,
            },
          ].map((link) => (
            <AniLink
              className="block text-white no-underline"
              cover
              key={link.title}
              to={link.route}
            >
              {link.title}
            </AniLink>
          ))}
        </nav>
        <Burger
          className={`${
            isOpen ? false : 'open'
          }`}
          onClick={() => toggleBurger(!isOpen)} />
      </div>
    </header>
  );
}

export default Header;
