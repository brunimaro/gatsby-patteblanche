import React from "react";
import { graphql } from 'gatsby';
import PropTypes from "prop-types";
import Img from 'gatsby-image';
import Layout from "../components/layout";
import SEO from "../components/seo";
//import fondNuage from "../images/fond-nuage.jpg";


const IndexPage = ({ data }) => (
    <Layout>
      <SEO
        keywords={[`gatsby`, `tailwind`, `react`, `tailwindcss`]}
        title="Home"
      />
      <section className="mb-20">
        <div className="flex">
          <div className="m-auto text-center">
            <h1>
            <span>Accompagner les organisations</span>
            vers une (r)évolution <br/>culturelle du monde qui vient
            </h1>
          </div>
        </div>
      </section>

      <section>
        <div className="flex">
          <div className="w-1/2">
          <Img
            fluid={data.nuage.childImageSharp.fluid}
          />
          </div>
          <div className="w-1/2 p-8">
          <p>Le monde change et évolue de plus en plus vite, se confrontant à ses limites et aux excès de notre société libérale, globale, qui a placé la consommation et la croissance au sommet de ses valeurs et objectifs. Face aux successions de crises passées et à venir, PatteBlanche se positionne comme un acteur militant des autres possibles, voulant s engager aux côtés de ceux qui font demain et en accompagnant les organisations dans leur transformation positive et à leur adaptabilité au monde post croissance qui s annonce.</p>
          <a href="#" className="bouton">Découvrir l Agence</a>
          </div>
        </div>

        <div className="mot text-center animate-pulse">
        (r)évolution
        </div>

      </section>

      <section className="mb-20">
        <div className="flex">
          <div className="m-auto text-center">
            <h1>vos besoins</h1>
          </div>
        </div>
      </section>

      <section className="mb-20">
        <div className="flex">
          <div className="m-auto text-center">
            <h1>quelques réalisations</h1>
          </div>
        </div>
      </section>

      <section className="mb-20">

        <div className="flex">
          <div className="m-auto text-center">
            <h1>Nos engagements</h1>
          </div>
        </div>

        <div className="flex mt-20">
          <div className="w-1/2 p-8">
          <p>Acteur des transitions depuis 2007, nous n’avons eu de cesse de grandir, autrement.</p>
          <p>Certifiés B Corp depuis 3 ans, nous avançons sur le chemin de l’amélioration continue.<br/>
          Best for workers deux ans de suite, nous continuons de viser mieux, pour chacun.</p>
          <p>Disciples d’une  Gouvernance partagée, nous apprenons, autant que nous sommes.</p>
          <p>Engagés aux côtés de ceux qui imaginent demain avec notre démarche probono. </p>
          <p>Citoyens d’une île que nous avons créé ensemble, pour mieux vivre le travail.</p>
          <p className="font-bold">Nous continuons de penser que nous pourrions faire mieux. Nous entendons le faire ensemble, à vos côtés </p>
          <a href="#" className="bouton">Découvrir</a>
          </div>
          <div className="w-1/2">
            <Img
              fluid={data.bateau.childImageSharp.fluid}
            />
          </div>

        </div>

      </section>

    </Layout>
);

IndexPage.propTypes= {
  data: PropTypes.object.isRequired,
};

export default IndexPage;

export const query = graphql`
  query {
    nuage: file(relativePath: { eq: "fond-nuage.jpg" }) {
      childImageSharp {
        fluid(maxWidth: 650, maxHeight: 650) {
          ...GatsbyImageSharpFluid
        }
      }
    }
    bateau: file(relativePath: { eq: "illus-bateau.jpg" }) {
      childImageSharp {
        fluid(maxWidth: 600, maxHeight: 750) {
          ...GatsbyImageSharpFluid
        }
      }
    }
  }
`
