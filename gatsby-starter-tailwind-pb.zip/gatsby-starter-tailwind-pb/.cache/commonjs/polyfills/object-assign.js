"use strict";

module.exports = Object.assign;